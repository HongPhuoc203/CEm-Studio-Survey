export type ElementType = 'kim' | 'moc' | 'thuy' | 'hoa' | 'tho';

export interface Option {
  id: string;
  label: string;
  subLabel?: string;
  description?: string;
  // Metadata for result generation
  vibeKeyword?: string; // Used for title generation
  visualSuggestion?: {
    outfit?: string;
    makeup?: string;
    lighting?: string;
    pose?: string;
    color?: string;
  };
}

export interface Question {
  id: string;
  text: string;
  options: Option[];
}

export interface ElementData {
  id: ElementType;
  name: string;
  englishName: string;
  description: string;
  colorTheme: string; // Tailwind class for text color
  bgTheme: string;    // Tailwind class for background
  step2: Question;    // The question for step 2 if this element is chosen
  step3: Question;    // The question for step 3 if this element is chosen
  baseResult: {
    palettes: string[];
    baseDesc: string;
  };
}

export interface QuizState {
  step: 'landing' | 'quiz-1' | 'quiz-2' | 'quiz-3' | 'result';
  selections: {
    element: ElementType | null;
    step2Id: string | null;
    step3Id: string | null;
  };
}
