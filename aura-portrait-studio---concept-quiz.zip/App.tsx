import React, { useState, useEffect } from 'react';
import { Hero } from './components/Hero';
import { Quiz } from './components/Quiz';
import { Result } from './components/Result';
import { QuizState, ElementType } from './types';

function App() {
  const [quizState, setQuizState] = useState<QuizState>({
    step: 'landing',
    selections: {
      element: null,
      step2Id: null,
      step3Id: null,
    },
  });

  const startQuiz = () => {
    setQuizState({ ...quizState, step: 'quiz-1' });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectElement = (elementId: ElementType) => {
    setQuizState((prev) => ({
      ...prev,
      step: 'quiz-2',
      selections: { ...prev.selections, element: elementId },
    }));
  };

  const handleSelectStep2 = (optionId: string) => {
    setQuizState((prev) => ({
      ...prev,
      step: 'quiz-3',
      selections: { ...prev.selections, step2Id: optionId },
    }));
  };

  const handleSelectStep3 = (optionId: string) => {
    setQuizState((prev) => ({
      ...prev,
      step: 'result',
      selections: { ...prev.selections, step3Id: optionId },
    }));
  };

  const goBack = () => {
    setQuizState((prev) => {
      if (prev.step === 'quiz-2') return { ...prev, step: 'quiz-1' };
      if (prev.step === 'quiz-3') return { ...prev, step: 'quiz-2' };
      if (prev.step === 'result') return { ...prev, step: 'quiz-3' };
      return prev;
    });
  };

  const resetQuiz = () => {
    setQuizState({
      step: 'landing',
      selections: { element: null, step2Id: null, step3Id: null },
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col font-sans text-slate-800">
      {quizState.step === 'landing' && <Hero onStart={startQuiz} />}
      
      {(quizState.step === 'quiz-1' || quizState.step === 'quiz-2' || quizState.step === 'quiz-3') && (
        <Quiz 
          state={quizState} 
          onSelectElement={handleSelectElement}
          onSelectStep2={handleSelectStep2}
          onSelectStep3={handleSelectStep3}
          onBack={goBack}
        />
      )}

      {quizState.step === 'result' && (
        <Result state={quizState} onReset={resetQuiz} />
      )}
    </div>
  );
}

export default App;
