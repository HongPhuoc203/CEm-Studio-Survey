import { ElementData, ElementType } from './types';

export const ELEMENTS: Record<ElementType, ElementData> = {
  kim: {
    id: 'kim',
    name: 'Kim',
    englishName: 'Metal',
    description: 'Bạn yêu thích sự chỉn chu, thanh lịch, rõ ràng. Năng lượng của bạn toát lên vẻ sắc sảo, kiên định và sang trọng.',
    colorTheme: 'text-slate-600',
    bgTheme: 'bg-slate-100',
    baseResult: {
      palettes: ['Trắng', 'Xám bạc', 'Vàng kim (Gold)', 'Đen'],
      baseDesc: 'Concept mang hơi thở hiện đại, tối giản nhưng đầy quyền lực.',
    },
    step2: {
      id: 'kim-style',
      text: 'Khi chụp ảnh, bạn muốn mình toát lên phong thái nào?',
      options: [
        { id: 'minimalist', label: 'Tối giản & Sang trọng', subLabel: 'Luxury Minimalist', vibeKeyword: 'Minimalist', visualSuggestion: { outfit: 'Suit trắng/đen form rộng, đầm lụa trơn', makeup: 'Clean girl look, nhấn khối nhẹ' } },
        { id: 'modern-office', label: 'Hiện đại & Tri thức', subLabel: 'Modern Professional', vibeKeyword: 'Boss Lady', visualSuggestion: { outfit: 'Blazer cắt xẻ lạ mắt, sơ mi lụa', makeup: 'Son nude đất, eyeliner mảnh' } },
        { id: 'glam', label: 'Lấp lánh & Quyền lực', subLabel: 'High Glamour', vibeKeyword: 'Glam', visualSuggestion: { outfit: 'Đầm sequin, phụ kiện kim loại lớn', makeup: 'Son đỏ rượu, nhũ mắt sáng' } },
        { id: 'classic', label: 'Cổ điển & Quý phái', subLabel: 'Timeless Classic', vibeKeyword: 'Classic', visualSuggestion: { outfit: 'Váy tweed, ngọc trai', makeup: 'Son đỏ cổ điển, tóc uốn xoăn lọn to' } },
        { id: 'futuristic', label: 'Phá cách & Tương lai', subLabel: 'Futuristic Edge', vibeKeyword: 'Avant-Garde', visualSuggestion: { outfit: 'Trang phục ánh kim, chất liệu da bóng', makeup: 'Makeup graphic, đính đá' } },
      ],
    },
    step3: {
      id: 'kim-mood',
      text: 'Bạn muốn ánh sáng và không gian trong bức ảnh như thế nào?',
      options: [
        { id: 'bright-studio', label: 'Studio phông trắng sáng', subLabel: 'High-key Lighting', visualSuggestion: { lighting: 'Ánh sáng đều, trong trẻo (High-key)', pose: 'Thẳng lưng, ánh mắt trực diện, tự tin' } },
        { id: 'dramatic-shadow', label: 'Tương phản mạnh & Bóng đổ', subLabel: 'Dramatic Shadows', visualSuggestion: { lighting: 'Ánh sáng cắt (Snoot), tạo khối mạnh', pose: 'Góc mặt nghiêng, thần thái lạnh lùng' } },
        { id: 'soft-window', label: 'Ánh sáng tự nhiên mềm mại', subLabel: 'Soft Natural', visualSuggestion: { lighting: 'Ánh sáng cửa sổ, hắt sáng nhẹ', pose: 'Thư thái, nhẹ nhàng, cầm ly rượu hoặc sách' } },
        { id: 'neon-city', label: 'Ánh đèn đêm đô thị', subLabel: 'City Lights', visualSuggestion: { lighting: 'Ánh sáng lạnh, bokeh đèn đường', pose: 'Bước đi, chuyển động tóc bay' } },
        { id: 'bw-art', label: 'Đen trắng nghệ thuật', subLabel: 'Black & White Art', visualSuggestion: { lighting: 'Đen trắng tương phản cao', pose: 'Tập trung vào đường nét khuôn mặt và tay' } },
      ],
    },
  },
  moc: {
    id: 'moc',
    name: 'Mộc',
    englishName: 'Wood',
    description: 'Bạn là người tự nhiên, chân thành và thích sự tự do. Năng lượng của bạn mang lại cảm giác dễ chịu, chữa lành và tươi mới.',
    colorTheme: 'text-emerald-700',
    bgTheme: 'bg-emerald-50',
    baseResult: {
      palettes: ['Xanh lá (Sage/Olive)', 'Nâu gỗ', 'Beige', 'Trắng kem'],
      baseDesc: 'Concept tôn vinh vẻ đẹp mộc mạc, gần gũi với thiên nhiên.',
    },
    step2: {
      id: 'moc-style',
      text: 'Bạn cảm thấy thoải mái nhất trong không gian nào?',
      options: [
        { id: 'forest', label: 'Rừng cây & Cỏ dại', subLabel: 'Forest Soul', vibeKeyword: 'Forest', visualSuggestion: { outfit: 'Váy linen, đầm maxi hoa nhí', makeup: 'Trong veo, má hồng say rượu' } },
        { id: 'garden', label: 'Vườn hoa thơ mộng', subLabel: 'Floral Garden', vibeKeyword: 'Bloom', visualSuggestion: { outfit: 'Váy voan nhiều tầng, màu pastel', makeup: 'Tông hồng đào ngọt ngào' } },
        { id: 'indoor-plant', label: 'Góc nhà nhiều cây xanh', subLabel: 'Cozy Greenery', vibeKeyword: 'Homey', visualSuggestion: { outfit: 'Trang phục ở nhà (Loungewear) aesthetic', makeup: 'Mặt mộc (No-makeup makeup)' } },
        { id: 'boho', label: 'Du mục & Phóng khoáng', subLabel: 'Bohemian Spirit', vibeKeyword: 'Boho', visualSuggestion: { outfit: 'Đồ thêu, tua rua, phụ kiện gỗ', makeup: 'Tông cam đất, tàn nhang giả' } },
        { id: 'zen', label: 'Tĩnh lặng & Thiền', subLabel: 'Zen Minimalist', vibeKeyword: 'Zen', visualSuggestion: { outfit: 'Trang phục cotton/đũi đơn sắc', makeup: 'Tự nhiên, tóc buông lơi' } },
      ],
    },
    step3: {
      id: 'moc-mood',
      text: 'Bạn muốn bức ảnh truyền tải cảm xúc gì?',
      options: [
        { id: 'dreamy', label: 'Mơ màng, nàng thơ', subLabel: 'Dreamy Muse', visualSuggestion: { lighting: 'Nắng xuyên qua kẽ lá (Dappled light)', pose: 'Nhắm mắt tận hưởng, xoay váy' } },
        { id: 'fresh', label: 'Tươi mới, tràn đầy sức sống', subLabel: 'Fresh & Joyful', visualSuggestion: { lighting: 'Nắng sớm trong trẻo', pose: 'Cười tươi, chạy nhảy tự nhiên' } },
        { id: 'deep', label: 'Trầm lắng, suy tư', subLabel: 'Deep Mood', visualSuggestion: { lighting: 'Ánh sáng chiều tà, mood trầm', pose: 'Ngồi tựa gốc cây, ánh mắt xa xăm' } },
        { id: 'wild', label: 'Hoang dã, cá tính', subLabel: 'Wild Soul', visualSuggestion: { lighting: 'Ánh sáng tự nhiên gắt (Hard light)', pose: 'Tương tác mạnh với thiên nhiên' } },
        { id: 'peaceful', label: 'Bình yên, nhẹ nhàng', subLabel: 'Peaceful', visualSuggestion: { lighting: 'Ánh sáng khuếch tán mềm', pose: 'Đọc sách, uống trà, tĩnh tại' } },
      ],
    },
  },
  thuy: {
    id: 'thuy',
    name: 'Thủy',
    englishName: 'Water',
    description: 'Bạn sâu sắc, linh hoạt và giàu cảm xúc. Tâm hồn bạn như dòng nước, lúc dịu êm, lúc dữ dội nhưng luôn đầy bí ẩn.',
    colorTheme: 'text-sky-700',
    bgTheme: 'bg-sky-50',
    baseResult: {
      palettes: ['Xanh dương', 'Trắng ngọc trai', 'Xanh cổ vịt', 'Đen huyền'],
      baseDesc: 'Concept khai thác sự mềm mại, uyển chuyển và chiều sâu nội tâm.',
    },
    step2: {
      id: 'thuy-style',
      text: 'Hình ảnh nào thu hút bạn nhất?',
      options: [
        { id: 'ocean', label: 'Biển cả bao la', subLabel: 'Ocean Breeze', vibeKeyword: 'Ocean', visualSuggestion: { outfit: 'Váy lụa dài bay bổng, màu xanh/trắng', makeup: 'Căng bóng (Dewy skin), son bóng' } },
        { id: 'rain', label: 'Mưa & Ký ức', subLabel: 'Rainy Mood', vibeKeyword: 'Melancholy', visualSuggestion: { outfit: 'Áo len mỏng, cầm ô trong suốt', makeup: 'Nhấn vào đôi mắt ướt' } },
        { id: 'mermaid', label: 'Nàng tiên cá bí ẩn', subLabel: 'Siren Core', vibeKeyword: 'Siren', visualSuggestion: { outfit: 'Đầm đuôi cá, đính kết ngọc trai', makeup: 'Nhũ mắt xanh/tím, tóc ướt (Wet look)' } },
        { id: 'mirror', label: 'Phản chiếu & Gương', subLabel: 'Reflection', vibeKeyword: 'Mirror', visualSuggestion: { outfit: 'Trang phục tối giản, chất liệu satin', makeup: 'Sắc sảo, lạnh lùng' } },
        { id: 'night-pool', label: 'Hồ bơi đêm & Ánh sáng', subLabel: 'Night Swim', vibeKeyword: 'Aqua', visualSuggestion: { outfit: 'Swimsuit thời trang hoặc váy bodycon', makeup: 'Chống nước, eyeliner sắc' } },
      ],
    },
    step3: {
      id: 'thuy-mood',
      text: 'Bạn thích phong cách kể chuyện (storytelling) nào?',
      options: [
        { id: 'ethereal', label: 'Huyền ảo, siêu thực', subLabel: 'Ethereal', visualSuggestion: { lighting: 'Ánh sáng mờ ảo, dùng khói (fog)', pose: 'Lơ lửng, múa, chuyển động tay mềm mại' } },
        { id: 'emotional', label: 'Cận cảnh cảm xúc', subLabel: 'Emotional Portrait', visualSuggestion: { lighting: 'Ánh sáng tập trung vào mắt', pose: 'Cận mặt, biểu cảm qua ánh mắt' } },
        { id: 'calm', label: 'Tĩnh lặng như mặt hồ', subLabel: 'Serenity', visualSuggestion: { lighting: 'Ánh sáng đều, softbox lớn', pose: 'Nằm, thả lỏng cơ thể hoàn toàn' } },
        { id: 'dynamic', label: 'Chuyển động của nước', subLabel: 'Fluid Motion', visualSuggestion: { lighting: 'Bắt dính chuyển động (High shutter)', pose: 'Hất tóc, tung váy tạo hình sóng' } },
        { id: 'dark', label: 'Bóng tối & Chiều sâu', subLabel: 'Deep Blue', visualSuggestion: { lighting: 'Low-key, ánh sáng xanh dương', pose: 'Co mình, bí ẩn, che giấu' } },
      ],
    },
  },
  hoa: {
    id: 'hoa',
    name: 'Hỏa',
    englishName: 'Fire',
    description: 'Bạn nhiệt huyết, đam mê và luôn tỏa sáng. Năng lượng của bạn rực rỡ, thu hút mọi ánh nhìn và đầy sức sống.',
    colorTheme: 'text-rose-700',
    bgTheme: 'bg-rose-50',
    baseResult: {
      palettes: ['Đỏ', 'Cam', 'Vàng chanh', 'Tím neon'],
      baseDesc: 'Concept bùng nổ, cá tính mạnh và gây ấn tượng thị giác cao.',
    },
    step2: {
      id: 'hoa-style',
      text: 'Bạn muốn thể hiện khía cạnh nào của bản thân?',
      options: [
        { id: 'fashion', label: 'High Fashion & Tạp chí', subLabel: 'Editorial', vibeKeyword: 'Editorial', visualSuggestion: { outfit: 'Thiết kế độc lạ, color block', makeup: 'Môi đỏ đậm, layout ấn tượng' } },
        { id: 'sexy', label: 'Quyến rũ & Nóng bỏng', subLabel: 'Femme Fatale', vibeKeyword: 'Seductive', visualSuggestion: { outfit: 'Váy xẻ cao, corset, ren đỏ', makeup: 'Mắt khói (Smokey eyes), son đỏ' } },
        { id: 'street', label: 'Bụi bặm đường phố', subLabel: 'Street Style', vibeKeyword: 'Urban', visualSuggestion: { outfit: 'Áo khoác da, denim, boots', makeup: 'Tông tây, contour rõ nét' } },
        { id: 'festival', label: 'Lễ hội & Rực rỡ', subLabel: 'Festival Queen', vibeKeyword: 'Vibrant', visualSuggestion: { outfit: 'Nhiều phụ kiện, lông vũ, màu neon', makeup: 'Đính đá, vẽ mặt nghệ thuật' } },
        { id: 'warmth', label: 'Ấm áp & Rạng rỡ', subLabel: 'Warm Soul', vibeKeyword: 'Sunny', visualSuggestion: { outfit: 'Váy len màu cam/đất nung', makeup: 'Má hồng cam cháy' } },
      ],
    },
    step3: {
      id: 'hoa-mood',
      text: 'Hiệu ứng ánh sáng nào làm bạn phấn khích?',
      options: [
        { id: 'sunset', label: 'Hoàng hôn rực lửa', subLabel: 'Golden Hour', visualSuggestion: { lighting: 'Ngược sáng (Backlight) vàng cam', pose: 'Hất mặt đón nắng, tự do' } },
        { id: 'studio-color', label: 'Gel màu studio (Red/Blue)', subLabel: 'Color Gel', visualSuggestion: { lighting: 'Đèn LED đổi màu, tương phản màu sắc', pose: 'Tạo dáng góc cạnh, thời trang' } },
        { id: 'flash', label: 'Đèn Flash trực diện', subLabel: 'Direct Flash', visualSuggestion: { lighting: 'Flash gắt, tạo bóng cứng', pose: 'Chuyển động nhanh, snapshot' } },
        { id: 'candle', label: 'Ánh nến lung linh', subLabel: 'Candlelight', visualSuggestion: { lighting: 'Ánh sáng yếu, ấm áp, lãng mạn', pose: 'Gần gũi, ấm cúng' } },
        { id: 'spotlight', label: 'Ánh đèn sân khấu', subLabel: 'Spotlight', visualSuggestion: { lighting: 'Một nguồn sáng (Spotlight) chiếu rọi', pose: 'Như đang trình diễn' } },
      ],
    },
  },
  tho: {
    id: 'tho',
    name: 'Thổ',
    englishName: 'Earth',
    description: 'Bạn điềm tĩnh, vững chãi và cổ điển. Năng lượng của bạn mang lại cảm giác tin cậy, ấm áp và hoài niệm.',
    colorTheme: 'text-amber-700',
    bgTheme: 'bg-amber-50',
    baseResult: {
      palettes: ['Nâu đất', 'Beige', 'Vàng mù tạt', 'Màu gạch'],
      baseDesc: 'Concept mang màu sắc hoài cổ, trầm ấm và tinh tế.',
    },
    step2: {
      id: 'tho-style',
      text: 'Phong cách thời trang nào bạn muốn thử?',
      options: [
        { id: 'vintage', label: 'Vintage & Retro', subLabel: 'Nostalgia', vibeKeyword: 'Vintage', visualSuggestion: { outfit: 'Váy hoa văn cổ điển, mũ nồi', makeup: 'Môi đỏ gạch, tóc uốn lọn nhỏ' } },
        { id: 'rustic', label: 'Rustic đồng quê', subLabel: 'Country Side', vibeKeyword: 'Rustic', visualSuggestion: { outfit: 'Yếm, đồ denim, sơ mi kẻ', makeup: 'Tự nhiên, tàn nhang' } },
        { id: 'dark-academia', label: 'Học giả cổ điển', subLabel: 'Dark Academia', vibeKeyword: 'Academia', visualSuggestion: { outfit: 'Blazer dạ, quần tây, tông nâu', makeup: 'Tông nâu tây trầm' } },
        { id: 'minimal-warm', label: 'Tối giản tông ấm', subLabel: 'Warm Minimalist', vibeKeyword: 'Warmth', visualSuggestion: { outfit: 'Trang phục linen màu be/nâu', makeup: 'No-makeup look, son dưỡng có màu' } },
        { id: 'clay', label: 'Nghệ thuật gốm sứ', subLabel: 'Artistic Clay', vibeKeyword: 'Sculptural', visualSuggestion: { outfit: 'Trang phục xếp nếp, màu nude/đất', makeup: 'Đồng nhất một tông màu (Monochrome)' } },
      ],
    },
    step3: {
      id: 'tho-mood',
      text: 'Bối cảnh nào khiến bạn thấy bình yên?',
      options: [
        { id: 'old-house', label: 'Căn nhà cổ/Quán cà phê xưa', subLabel: 'Old Architecture', visualSuggestion: { lighting: 'Ánh sáng tự nhiên qua cửa gỗ', pose: 'Ngồi đọc sách, nhìn qua cửa sổ' } },
        { id: 'field', label: 'Cánh đồng cỏ khô', subLabel: 'Dried Field', visualSuggestion: { lighting: 'Nắng chiều vàng ruộm', pose: 'Chạy trên cỏ, nằm dài thư giãn' } },
        { id: 'studio-brown', label: 'Studio phông nâu/be', subLabel: 'Brown Studio', visualSuggestion: { lighting: 'Ánh sáng mịn, ấm', pose: 'Chân dung bán thân, tĩnh' } },
        { id: 'film', label: 'Màu ảnh phim (Film look)', subLabel: 'Analog Vibes', visualSuggestion: { lighting: 'Hạt (Grain), màu giả lập phim', pose: 'Candid (bắt khoảnh khắc tự nhiên)' } },
        { id: 'sunset-home', label: 'Hoàng hôn tại nhà', subLabel: 'Golden Home', visualSuggestion: { lighting: 'Nắng hắt lên tường', pose: 'Thân mật, đời thường' } },
      ],
    },
  },
};
