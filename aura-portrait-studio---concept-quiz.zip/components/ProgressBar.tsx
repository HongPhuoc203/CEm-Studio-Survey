import React from 'react';

interface ProgressBarProps {
  current: number;
  total: number;
}

export const ProgressBar: React.FC<ProgressBarProps> = ({ current, total }) => {
  return (
    <div className="w-full flex flex-col items-center">
      <div className="flex justify-between w-full mb-2 text-xs uppercase tracking-widest text-stone-400 font-medium">
        <span>Bắt đầu</span>
        <span className="text-stone-800">Bước {current} / {total}</span>
        <span>Kết quả</span>
      </div>
      <div className="w-full h-1 bg-stone-200 rounded-full overflow-hidden">
        <div 
          className="h-full bg-stone-800 transition-all duration-500 ease-out"
          style={{ width: `${(current / total) * 100}%` }}
        ></div>
      </div>
    </div>
  );
};
