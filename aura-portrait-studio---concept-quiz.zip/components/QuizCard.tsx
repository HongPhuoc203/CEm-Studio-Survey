import React from 'react';

interface QuizCardProps {
  title: string;
  subtitle?: string;
  description?: string;
  onClick: () => void;
  colorTheme?: string;
  bgTheme?: string;
}

export const QuizCard: React.FC<QuizCardProps> = ({ 
  title, 
  subtitle, 
  description, 
  onClick, 
  colorTheme = 'text-stone-800',
  bgTheme = 'bg-white' 
}) => {
  return (
    <button 
      onClick={onClick}
      className={`
        flex flex-col items-center justify-center text-center p-6 
        rounded-xl shadow-sm hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1
        border border-stone-100 h-full w-full min-h-[200px]
        group ${bgTheme}
      `}
    >
      <h3 className={`text-xl md:text-2xl font-serif mb-2 ${colorTheme}`}>
        {title}
      </h3>
      
      {subtitle && (
        <span className="text-xs uppercase tracking-widest text-stone-400 mb-4 font-medium group-hover:text-stone-600 transition-colors">
          {subtitle}
        </span>
      )}
      
      {description && (
        <p className="text-sm text-stone-500 leading-relaxed font-light">
          {description}
        </p>
      )}
    </button>
  );
};
