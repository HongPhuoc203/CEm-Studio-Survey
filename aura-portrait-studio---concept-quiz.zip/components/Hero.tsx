import React from 'react';
import { Camera, Sparkles } from 'lucide-react';

interface HeroProps {
  onStart: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onStart }) => {
  return (
    <div className="relative w-full min-h-screen flex flex-col items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 z-0 bg-cover bg-center bg-no-repeat opacity-90"
        style={{ 
          backgroundImage: 'url("https://picsum.photos/1920/1080?grayscale&blur=2")', 
        }} 
      >
         <div className="absolute inset-0 bg-black/40"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 px-6 text-center text-white max-w-4xl mx-auto flex flex-col items-center fade-in">
        <div className="mb-4 flex items-center justify-center space-x-2 text-yellow-100/80">
          <Camera size={24} />
          <span className="uppercase tracking-[0.2em] text-sm">Aura Portrait Studio</span>
        </div>
        
        <h1 className="text-5xl md:text-7xl font-serif font-light mb-6 leading-tight">
          Khám Phá Concept <br/>
          <span className="italic">Dành Riêng Cho Bạn</span>
        </h1>
        
        <p className="text-lg md:text-xl text-gray-200 mb-10 max-w-2xl font-light">
          Mỗi người đều mang một nguồn năng lượng riêng biệt. Hãy để chúng tôi giúp bạn tìm ra phong cách chụp ảnh tôn vinh vẻ đẹp tâm hồn của bạn thông qua ngũ hành.
        </p>
        
        <button 
          onClick={onStart}
          className="group relative px-8 py-4 bg-white text-stone-900 text-lg tracking-widest uppercase transition-all duration-300 hover:bg-stone-200 hover:scale-105 shadow-xl"
        >
          <span className="flex items-center gap-3">
            Bắt đầu khảo sát
            <Sparkles size={18} className="text-yellow-600" />
          </span>
        </button>

        {/* Steps Preview */}
        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8 text-sm opacity-80 max-w-3xl">
          <div className="flex flex-col items-center">
            <div className="w-8 h-8 rounded-full border border-white/30 flex items-center justify-center mb-2">1</div>
            <p>Chọn nguyên tố ngũ hành</p>
          </div>
          <div className="flex flex-col items-center">
            <div className="w-8 h-8 rounded-full border border-white/30 flex items-center justify-center mb-2">2</div>
            <p>Định hình phong cách</p>
          </div>
          <div className="flex flex-col items-center">
            <div className="w-8 h-8 rounded-full border border-white/30 flex items-center justify-center mb-2">3</div>
            <p>Nhận gợi ý concept</p>
          </div>
        </div>
      </div>
    </div>
  );
};
