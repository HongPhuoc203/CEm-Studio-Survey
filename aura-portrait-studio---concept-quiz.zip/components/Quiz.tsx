import React from 'react';
import { ElementType, QuizState } from '../types';
import { ELEMENTS } from '../constants';
import { QuizCard } from './QuizCard';
import { ProgressBar } from './ProgressBar';
import { ArrowLeft } from 'lucide-react';

interface QuizProps {
  state: QuizState;
  onSelectElement: (id: ElementType) => void;
  onSelectStep2: (id: string) => void;
  onSelectStep3: (id: string) => void;
  onBack: () => void;
}

export const Quiz: React.FC<QuizProps> = ({ state, onSelectElement, onSelectStep2, onSelectStep3, onBack }) => {
  const currentStepNumber = state.step === 'quiz-1' ? 1 : state.step === 'quiz-2' ? 2 : 3;

  const renderContent = () => {
    // STEP 1: CHOOSE ELEMENT
    if (state.step === 'quiz-1') {
      return (
        <div className="fade-in">
          <h2 className="text-3xl md:text-4xl font-serif text-center mb-2 text-stone-800">
            Bước 1: Năng lượng của bạn
          </h2>
          <p className="text-center text-stone-500 mb-10 max-w-xl mx-auto">
            Bạn cảm thấy bản thân mình cộng hưởng mạnh mẽ nhất với nguyên tố nào dưới đây?
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {Object.values(ELEMENTS).map((el) => (
              <QuizCard
                key={el.id}
                title={el.name}
                subtitle={el.englishName}
                description={el.description}
                onClick={() => onSelectElement(el.id)}
                colorTheme={el.colorTheme}
                bgTheme={el.bgTheme}
              />
            ))}
          </div>
        </div>
      );
    }

    // STEP 2: CHOOSE STYLE
    if (state.step === 'quiz-2' && state.selections.element) {
      const element = ELEMENTS[state.selections.element];
      const question = element.step2;
      return (
        <div className="fade-in">
          <h2 className="text-3xl md:text-4xl font-serif text-center mb-2 text-stone-800">
            Bước 2: Phong cách mong muốn
          </h2>
          <p className="text-center text-stone-500 mb-10 max-w-xl mx-auto">
            {question.text}
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {question.options.map((opt) => (
              <QuizCard
                key={opt.id}
                title={opt.label}
                subtitle={opt.subLabel}
                onClick={() => onSelectStep2(opt.id)}
                colorTheme={element.colorTheme}
                bgTheme="bg-white" // Keep options neutral but with colored text
              />
            ))}
          </div>
        </div>
      );
    }

    // STEP 3: CHOOSE MOOD/DETAIL
    if (state.step === 'quiz-3' && state.selections.element) {
      const element = ELEMENTS[state.selections.element];
      const question = element.step3;
      return (
        <div className="fade-in">
          <h2 className="text-3xl md:text-4xl font-serif text-center mb-2 text-stone-800">
            Bước 3: Chi tiết & Cảm xúc
          </h2>
          <p className="text-center text-stone-500 mb-10 max-w-xl mx-auto">
            {question.text}
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {question.options.map((opt) => (
              <QuizCard
                key={opt.id}
                title={opt.label}
                subtitle={opt.subLabel}
                onClick={() => onSelectStep3(opt.id)}
                colorTheme={element.colorTheme}
                bgTheme="bg-white"
              />
            ))}
          </div>
        </div>
      );
    }
  };

  return (
    <div className="min-h-screen bg-stone-50 py-12 px-4 md:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header with Progress */}
        <div className="mb-12 max-w-2xl mx-auto">
          <ProgressBar current={currentStepNumber} total={3} />
        </div>

        {/* Back Button */}
        {state.step !== 'quiz-1' && (
           <button 
             onClick={onBack}
             className="mb-6 flex items-center text-stone-500 hover:text-stone-800 transition-colors text-sm uppercase tracking-wide"
           >
             <ArrowLeft size={16} className="mr-2" /> Quay lại
           </button>
        )}

        {/* Content Area */}
        {renderContent()}

        {/* Footer Note */}
        <div className="mt-16 text-center text-xs text-stone-400 italic">
          * Chỉ mất 1-2 phút để hoàn thành khảo sát
        </div>
      </div>
    </div>
  );
};
