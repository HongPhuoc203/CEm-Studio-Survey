import React from 'react';
import { QuizState } from '../types';
import { ELEMENTS } from '../constants';
import { RefreshCcw, Calendar, Download, Share2 } from 'lucide-react';

interface ResultProps {
  state: QuizState;
  onReset: () => void;
}

export const Result: React.FC<ResultProps> = ({ state, onReset }) => {
  const { element: elId, step2Id, step3Id } = state.selections;

  if (!elId || !step2Id || !step3Id) return null;

  const element = ELEMENTS[elId];
  const step2Option = element.step2.options.find(o => o.id === step2Id);
  const step3Option = element.step3.options.find(o => o.id === step3Id);

  if (!step2Option || !step3Option) return null;

  // Dynamic Content Generation
  const conceptName = `Concept: ${element.name} ${step2Option.vibeKeyword} ${step3Option.subLabel}`;
  
  // Combine suggestions
  const outfit = step2Option.visualSuggestion?.outfit || step3Option.visualSuggestion?.outfit || "Tự do theo cá tính";
  const makeup = step2Option.visualSuggestion?.makeup || "Tự nhiên, tôn nét mặt";
  const lighting = step3Option.visualSuggestion?.lighting || "Ánh sáng studio tiêu chuẩn";
  const pose = step3Option.visualSuggestion?.pose || "Tự nhiên, thoải mái";
  
  // Colors: element base + maybe a twist from step 2 if we had it, but mostly element
  const palette = element.baseResult.palettes.join(' • ');

  return (
    <div className="min-h-screen bg-stone-50 py-12 px-4 md:px-8 flex flex-col items-center animate-fade-in">
      
      {/* Result Card */}
      <div className="bg-white w-full max-w-4xl shadow-2xl rounded-sm overflow-hidden border border-stone-100">
        
        {/* Header Image Area - Could be dynamic based on Element */}
        <div className={`h-40 ${element.bgTheme} w-full flex items-center justify-center p-8`}>
            <div className="text-center">
                 <span className="uppercase tracking-[0.3em] text-xs text-stone-500 bg-white/50 px-3 py-1 rounded-full mb-3 inline-block">
                     Kết quả phù hợp nhất
                 </span>
                 <h2 className={`text-4xl md:text-5xl font-serif ${element.colorTheme}`}>
                    {conceptName}
                 </h2>
            </div>
        </div>

        <div className="p-8 md:p-12">
            
            {/* Description */}
            <div className="mb-12 text-center max-w-2xl mx-auto">
                <p className="text-lg md:text-xl text-stone-600 font-light leading-relaxed">
                    "{element.baseResult.baseDesc} Sự kết hợp giữa phong cách <strong>{step2Option.label}</strong> và không gian <strong>{step3Option.label}</strong> tạo nên một tổng thể hài hòa, tôn vinh khí chất {element.name} độc bản của bạn."
                </p>
            </div>

            {/* Visual Direction Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-10 mb-12">
                <div>
                    <h3 className="text-lg font-serif italic border-b border-stone-200 pb-2 mb-4 text-stone-800">
                        Định hướng hình ảnh
                    </h3>
                    <ul className="space-y-4">
                        <li className="flex flex-col">
                            <span className="text-xs uppercase tracking-wider text-stone-400 font-semibold">Gam màu chủ đạo</span>
                            <span className="text-stone-700 font-medium">{palette}</span>
                        </li>
                        <li className="flex flex-col">
                            <span className="text-xs uppercase tracking-wider text-stone-400 font-semibold">Ánh sáng</span>
                            <span className="text-stone-700">{lighting}</span>
                        </li>
                         <li className="flex flex-col">
                            <span className="text-xs uppercase tracking-wider text-stone-400 font-semibold">Pose & Cảm xúc</span>
                            <span className="text-stone-700">{pose}</span>
                        </li>
                    </ul>
                </div>

                <div>
                    <h3 className="text-lg font-serif italic border-b border-stone-200 pb-2 mb-4 text-stone-800">
                        Styling & Makeup
                    </h3>
                    <ul className="space-y-4">
                        <li className="flex flex-col">
                            <span className="text-xs uppercase tracking-wider text-stone-400 font-semibold">Trang phục</span>
                            <span className="text-stone-700">{outfit}</span>
                        </li>
                        <li className="flex flex-col">
                            <span className="text-xs uppercase tracking-wider text-stone-400 font-semibold">Makeup & Hair</span>
                            <span className="text-stone-700">{makeup}</span>
                        </li>
                    </ul>
                </div>
            </div>

            {/* Actions */}
            <div className="flex flex-col md:flex-row gap-4 justify-center items-center pt-8 border-t border-stone-100">
                <button 
                  onClick={() => window.print()} 
                  className="w-full md:w-auto px-6 py-3 border border-stone-300 text-stone-600 hover:bg-stone-50 transition-colors flex items-center justify-center gap-2 uppercase text-sm tracking-wider"
                >
                    <Download size={16} /> Lưu kết quả
                </button>
                
                <a 
                  href={`mailto:booking@aurastudio.com?subject=Booking Concept: ${conceptName}`}
                  className="w-full md:w-auto px-8 py-3 bg-stone-800 text-white hover:bg-stone-700 transition-colors shadow-lg hover:shadow-xl flex items-center justify-center gap-2 uppercase text-sm tracking-wider"
                >
                    <Calendar size={16} /> Đặt lịch chụp
                </a>
            </div>
            
            <p className="mt-6 text-center text-xs text-stone-400">
                Điền thông tin của bạn, Aura Studio sẽ tư vấn chi tiết dựa trên concept này.
            </p>

        </div>
      </div>

      <button 
        onClick={onReset}
        className="mt-12 text-stone-400 hover:text-stone-600 flex items-center gap-2 text-sm transition-colors"
      >
        <RefreshCcw size={14} /> Làm lại khảo sát
      </button>

    </div>
  );
};
